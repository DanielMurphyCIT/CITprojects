import time
from concurrent import futures
from os.path import exists
import grpc
import wordData_pb2 as wordData_pb2
import wordData_pb2_grpc as wordData_pb2_grpc
import os 
dir_path = os.path.dirname(os.path.realpath(__file__))

_ONE_DAY_IN_SECONDS = 60 * 60 * 24


class gRPCServer(wordData_pb2_grpc.MyServiceServicer):
    def SendStatistics(self, request_iterator, context):
        with open('PARIS AGREEMENT.txt','r') as f:
        	for line in f:
        		for word in line.split():
        			yield wordData_pb2.MyResponse(word = word)


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=100))
    wordData_pb2_grpc.add_MyServiceServicer_to_server(
        gRPCServer(), server)
    server.add_insecure_port('[::]:5051')
    server.start()
    try:
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)


if __name__ == '__main__':
    serve()
