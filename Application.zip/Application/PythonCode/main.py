from flask import Flask, request, redirect, url_for
from flask import render_template
import time
import random
import os
import grpc
import streamData_pb2 as streamData_pb2
import streamData_pb2_grpc as streamData_pb2_grpc
import flask_monitoringdashboard as dashboard

app = Flask(__name__)
dashboard.bind(app)

SECRET_KEY = os.urandom(32)
app.config['SECRET_KEY'] = SECRET_KEY

class gRPCClient():
    def __init__(self):
        channel = grpc.insecure_channel('localhost:5049')
        self.stub = streamData_pb2_grpc.MyFlaskServiceStub(channel)

    def SendWord(self):
        return self.stub.SendWordCount(streamData_pb2.MyDataRequest(DataPlease=1), wait_for_ready=True)
    def getSentenceAvg(self):
        return self.stub.SendAvgSentence(streamData_pb2.MyDataRequest(DataPlease=1), wait_for_ready=True)
    def getWordAvg(self):
        return self.stub.SendAvgWord(streamData_pb2.MyDataRequest(DataPlease=1), wait_for_ready=True)
    	
def createWordList(df):
    words = []
    count = []        
    for word in df:
        words.append(word.wordStream)
        count.append(word.countStream)
    return words, count   

@app.route('/', methods=['GET','POST'])
def search():
    client = gRPCClient()
    res = client.SendWord()
    sentenceAvg = client.getSentenceAvg()
    wordAvg = client.getWordAvg()
    word, count = createWordList(res)
    return render_template("index.html", title='Paris Agreement', word=word, count=count, sentenceAvg=sentenceAvg, wordAvg=wordAvg)



if __name__== "__main__":
    #app.debug = True
    app.run()
