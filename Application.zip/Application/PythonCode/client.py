import random
import time
import string
from concurrent import futures
import grpc
import pandas as pd
import wordData_pb2 as wordData_pb2
import wordData_pb2_grpc as wordData_pb2_grpc
import streamData_pb2 as streamData_pb2
import streamData_pb2_grpc as streamData_pb2_grpc
import warnings
warnings.filterwarnings("ignore")
_ONE_DAY_IN_SECONDS = 60 * 60 * 24
finaldict = {}
avgSentence = 0
avgWord = 0

class gRPCServer(streamData_pb2_grpc.MyFlaskServiceServicer):
    def __init__(self):
        print('initialization')

    def SendWordCount(self, request_iterator, context):
        for key, value in finaldict.items():
            yield streamData_pb2.MyStreamResponse(wordStream = key, countStream = value)
    def SendAvgSentence(self, request_iterator, context):
        return streamData_pb2.MySentenceResponse(avgSentence = avgSentence)
    def SendAvgWord(self, request_iterator, context):
        return streamData_pb2.MyWordResponse(avgWord = avgWord)
       

class gRPCClient():
    def __init__(self):
        channel = grpc.insecure_channel('localhost:5051')
        self.stub = wordData_pb2_grpc.MyServiceStub(channel)

    def method3(self, req):
        return self.stub.SendStatistics(req)

def generateRequests():
    reqs = [wordData_pb2.MyRequest(SendData=1)]
    for req in reqs:
        yield req
        time.sleep(0.001)


def serve(df):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=100))
    streamData_pb2_grpc.add_MyFlaskServiceServicer_to_server(
        gRPCServer(), server)
    server.add_insecure_port('[::]:5049')
    server.start()
    try:
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)

def getListAvg(lst):
    return sum(lst) / len(lst) 

def testAlphaNumeric(word):
    new_word = word.translate(str.maketrans('', '', string.punctuation))
    return new_word.isalpha()

def removePunctuation(word):
    return word.translate(str.maketrans('', '', string.punctuation))

def getWordCount(res):
    global avgSentence
    global avgWord
    worddict = {
    "food": 0,
    "technology": 0,
    "deforestation": 0,
    "socioeconomic": 0,
    "ecological": 0,
    "diversification": 0,
    "sustainability": 0,
    "advice": 0,
    "parties": 0,
    }
    sentenceLength = []
    wordList = []
    count = 0
    for re in res:
        count +=1
        if re.word.lower() in worddict:
            worddict[re.word.lower()]+=1
        if(removePunctuation(re.word).isalpha()):
            wordList.append(len(removePunctuation(re.word)))
        if "." in re.word and testAlphaNumeric(re.word):
            sentenceLength.append(count)
            count = 0            
    avgSentence = getListAvg(sentenceLength)
    avgWord = getListAvg(wordList)
    for key, value in worddict.items():
        finaldict[key] = value
    return worddict
  	        	  

def main():
    client = gRPCClient()
    res = client.method3(generateRequests())
    getWordCount(res)
    serve(finaldict)
    
    

if __name__ == '__main__':
    main()
    
